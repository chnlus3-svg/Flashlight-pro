package com.rahul.flashlightpro

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var cameraManager: CameraManager
    private var cameraId: String? = null
    private var torchOn = false
    private var strengthMax = 1
    private var requestedPercent = 100
    private lateinit var status: TextView
    private lateinit var percentLabel: TextView
    private lateinit var slider: SeekBar
    private lateinit var toggle: Button
    private lateinit var limitation: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        buildUi()
        findFlashCamera()
        updateUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(32), dp(24), dp(24))
            setBackgroundColor(0xFF111827.toInt())
        }
        fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(text("🔦  Flashlight Pro", 27f, 0xFFFFFFFF.toInt(), true), params(LinearLayout.LayoutParams.MATCH_PARENT, dp(60)))
        status = text("TORCH OFF", 22f, 0xFFFACC15.toInt(), true)
        root.addView(status, params(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)))
        val toggleArea = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(20), 0, dp(20)) }
        toggle = Button(this).apply {
            text = "TURN ON"
            textSize = 19f
            setOnClickListener { if (torchOn) turnOff() else turnOn() }
        }
        toggleArea.addView(toggle, params(dp(220), dp(80)))
        root.addView(toggleArea)
        percentLabel = text("Brightness: 100%", 18f, 0xFFFFFFFF.toInt(), true)
        root.addView(percentLabel, params(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)))
        slider = SeekBar(this).apply {
            max = 99
            progress = 99
            contentDescription = "Brightness from 1 to 100 percent"
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    requestedPercent = progress + 1
                    percentLabel.text = "Brightness: $requestedPercent%"
                    if (fromUser && torchOn) applyStrength(requestedPercent)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        root.addView(slider, params(LinearLayout.LayoutParams.MATCH_PARENT, dp(56)))
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val minus = Button(this).apply { text = "− 10%"; setOnClickListener { setPercent(requestedPercent - 10) } }
        val plus = Button(this).apply { text = "+ 10%"; setOnClickListener { setPercent(requestedPercent + 10) } }
        controls.addView(minus, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(8) })
        controls.addView(plus, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(8) })
        root.addView(controls, params(LinearLayout.LayoutParams.MATCH_PARENT, dp(64)))
        val presets = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        listOf(25, 50, 75, 100).forEach { value ->
            presets.addView(Button(this).apply { text = "$value%"; setOnClickListener { setPercent(value) } }, LinearLayout.LayoutParams(0, dp(52), 1f))
        }
        root.addView(presets, params(LinearLayout.LayoutParams.MATCH_PARENT, dp(62)))
        limitation = text("Checking flash hardware…", 14f, 0xFFD1D5DB.toInt())
        limitation.setPadding(0, dp(24), 0, 0)
        root.addView(limitation, params(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        val note = text("Brightness control depends on your phone's hardware. Avoid staring directly into the LED.", 12f, 0xFF9CA3AF.toInt())
        note.setPadding(0, dp(18), 0, 0)
        root.addView(note, params(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }

    private fun findFlashCamera() {
        try {
            cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
            val id = cameraId
            if (id == null) {
                limitation.text = "No rear flash found on this device."
                toggle.isEnabled = false; slider.isEnabled = false
                return
            }
            if (Build.VERSION.SDK_INT >= 33) {
                strengthMax = cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
                if (strengthMax > 1) {
                    limitation.text = "Variable brightness supported: $strengthMax hardware levels. Slider uses the closest supported level."
                } else {
                    limitation.text = "This phone reports only one flash strength level. Brightness may be ON/OFF only."
                }
            } else {
                strengthMax = 1
                slider.isEnabled = false
                limitation.text = "This Android version supports torch ON/OFF here; variable brightness needs Android 13+ and compatible hardware."
            }
        } catch (e: Exception) {
            limitation.text = "Could not inspect flash hardware: ${e.localizedMessage ?: "unknown error"}"
            toggle.isEnabled = false
        }
    }

    private fun setPercent(value: Int) {
        requestedPercent = value.coerceIn(1, 100)
        slider.progress = requestedPercent - 1
        percentLabel.text = "Brightness: $requestedPercent%"
        if (torchOn) applyStrength(requestedPercent)
    }

    private fun turnOn() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 101)
            return
        }
        val id = cameraId ?: return toast("No compatible flash found")
        try {
            if (Build.VERSION.SDK_INT >= 33 && strengthMax > 1) {
                val level = (1 + ((requestedPercent - 1) * (strengthMax - 1) / 99.0)).toInt().coerceIn(1, strengthMax)
                cameraManager.turnOnTorchWithStrengthLevel(id, level)
            } else cameraManager.setTorchMode(id, true)
            torchOn = true
            updateUi()
        } catch (e: CameraAccessException) { toast("Torch unavailable. Close the camera app and try again.") }
        catch (e: SecurityException) { toast("Camera permission is required.") }
        catch (e: Exception) { toast("Could not turn on torch: ${e.localizedMessage ?: "error"}") }
    }

    private fun applyStrength(percent: Int) {
        val id = cameraId ?: return
        if (Build.VERSION.SDK_INT < 33 || strengthMax <= 1) return
        try {
            val level = (1 + ((percent - 1) * (strengthMax - 1) / 99.0)).toInt().coerceIn(1, strengthMax)
            cameraManager.turnOnTorchWithStrengthLevel(id, level)
        } catch (e: Exception) { toast("This phone cannot change brightness right now.") }
    }

    private fun turnOff() {
        val id = cameraId ?: return
        try { cameraManager.setTorchMode(id, false); torchOn = false; updateUi() }
        catch (e: Exception) { toast("Could not turn off torch. Try again.") }
    }

    private fun updateUi() {
        status.text = if (torchOn) "TORCH ON" else "TORCH OFF"
        toggle.text = if (torchOn) "TURN OFF" else "TURN ON"
        status.setTextColor(if (torchOn) 0xFF86EFAC.toInt() else 0xFFFACC15.toInt())
        if (::status.isInitialized) {
            // The label remains visible above the main control.
            (status.parent as? LinearLayout)?.let { }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) turnOn()
        else if (requestCode == 101) toast("Camera permission is needed to control the flashlight.")
    }

    override fun onPause() { super.onPause() }
    override fun onDestroy() { if (torchOn) { try { cameraId?.let { cameraManager.setTorchMode(it, false) } } catch (_: Exception) {} }; super.onDestroy() }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun params(width: Int, height: Int) = LinearLayout.LayoutParams(width, height)
}
