plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rahul.flashlightpro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rahul.flashlightpro"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }

    kotlinOptions { jvmTarget = "17" }
}
