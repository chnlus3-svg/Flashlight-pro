# Flashlight Pro (Android)

Native Android starter project for a real device flashlight with ON/OFF, a 1–100% slider, +/- 10% buttons, and 25/50/75/100% presets.

## Build APK in Android Studio
1. Install Android Studio (current stable) and its Android SDK Platform 35 / Build Tools.
2. Open this `FlashlightPro` folder as a project and allow Gradle sync.
3. Connect an Android phone with USB debugging enabled, or use a compatible device/emulator (emulators generally do not have a real LED flash).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The APK will be under `app/build/outputs/apk/debug/app-debug.apk`.

## Hardware limitations
- Android 13 (API 33)+ and device hardware support are required for `turnOnTorchWithStrengthLevel` variable-strength control.
- Many devices expose only one strength level and effectively support ON/OFF only.
- The 1–100% UI maps to the closest hardware strength level; it is not a calibrated measurement of light output and may not be linear.
- Camera permission is requested because Android's flashlight API uses camera permission. Other camera apps may temporarily make the flash unavailable.

Package: `com.rahul.flashlightpro`
